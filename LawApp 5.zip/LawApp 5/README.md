# LawApp
//this is the readme for our law app
